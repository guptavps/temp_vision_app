const express = require('express');
require('dotenv').config({path: './.env'});
const app = express();
const bodyParser = require('body-parser')
const port = process.env.PORT || 8090;

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

console.log(`Your port is ${port}`);

const request = require('request');

app.get('/test', (req, res) => {
  res.send('This is working');
});


    app.listen(port, () => {
     console.log('Running with environment set to {' + process.env.NODE_ENV + '}');
     console.log('Server is up on {' + port + '}');
 }); 



